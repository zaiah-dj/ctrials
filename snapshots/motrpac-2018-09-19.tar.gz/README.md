# motrpac - Intervention Tracking

Good morrow, and I hope this document finds you in good health.
This is the documentation for the Motrpac Intervention Tracking application, a stand-alone app capable of tracking participant metrics during the Motrpac study.



## Table of Contents

work to do... 



## Setup 


### Running Locally

You will need:

- SQL Server (Runs on Linux, OSX and Windows)
- Git Bash (or some other Unix-compatible shell)

Optional:

- GNU Make


### ???


## Usage


## Developer Notes
