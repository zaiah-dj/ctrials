/*eetl_constants.sql - All constants for frm_eetl values*/
