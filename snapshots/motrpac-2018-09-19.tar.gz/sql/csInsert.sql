INSERT INTO
 ac_mtr_session_metadata
( 
	sm_siteid
, sm_datetimestarted
, sm_dayofweek
, sm_dayofmonth
, sm_month
, sm_year 
)
VALUES
( 
	:site_id 
, :dtstarted
, :dayofwk
, :dayofmonth
, :month
, :year 
)
