

/*RE n1*/	
INSERT INTO [zProgrammer_AntonioCollins].[dbo].[frm_RETL]([insertedBy], [dayofwk], [stdywk], [typedata], [weight], [participantGUID], [d_visit], [staffID], [mchntype])
VALUES(1049, 3, 1, 1, 180, '96EAB663-6804-4624-88AB-720D71C602E0', '2018-08-08', '1049', 1);

INSERT INTO [zProgrammer_AntonioCollins].[dbo].[frm_RETL]([insertedBy], [dayofwk], [stdywk], [typedata], [weight], [participantGUID], [d_visit], [staffID], [mchntype])
VALUES(1049, 4, 1, 1, 180, '96EAB663-6804-4624-88AB-720D71C602E0', '2018-08-08', '1049', 1);

INSERT INTO [zProgrammer_AntonioCollins].[dbo].[frm_RETL]([insertedBy], [dayofwk], [stdywk], [typedata], [weight], [participantGUID], [d_visit], [staffID], [mchntype])
VALUES(1049, 2, 2, 1, 180, '96EAB663-6804-4624-88AB-720D71C602E0', '2018-08-08', '1049', 1);

INSERT INTO [zProgrammer_AntonioCollins].[dbo].[frm_RETL]([insertedBy], [dayofwk], [stdywk], [typedata], [weight], [participantGUID], [d_visit], [staffID], [mchntype])
VALUES(1049, 4, 2, 1, 180, '96EAB663-6804-4624-88AB-720D71C602E0', '2018-08-08', '1049', 1);

INSERT INTO [zProgrammer_AntonioCollins].[dbo].[frm_RETL]([insertedBy], [dayofwk], [stdywk], [typedata], [weight], [participantGUID], [d_visit], [staffID], [mchntype])
VALUES(1049, 3, 4, 1, 180, '96EAB663-6804-4624-88AB-720D71C602E0', '2018-08-08', '1049', 1);




/*RE n1*/
INSERT INTO [zProgrammer_AntonioCollins].[dbo].[frm_RETL]([insertedBy], [dayofwk], [stdywk], [typedata], [weight], [participantGUID], [d_visit], [staffID], [bodyPart])
VALUES(1049, 2, 1, 1, 180, '6AD200F6-BF4F-4C83-8893-0A6CBDB9FB9F', '2018-08-08', '1049', 1);

INSERT INTO [zProgrammer_AntonioCollins].[dbo].[frm_RETL]([insertedBy], [dayofwk], [stdywk], [typedata], [weight], [participantGUID], [d_visit], [staffID], [bodyPart])
VALUES(1049, 3, 1, 1, 180, '6AD200F6-BF4F-4C83-8893-0A6CBDB9FB9F', '2018-08-08', '1049', 1);

INSERT INTO [zProgrammer_AntonioCollins].[dbo].[frm_RETL]([insertedBy], [dayofwk], [stdywk], [typedata], [weight], [participantGUID], [d_visit], [staffID], [bodyPart])
VALUES(1049, 4, 1, 1, 180, '6AD200F6-BF4F-4C83-8893-0A6CBDB9FB9F', '2018-08-08', '1049', 1);

INSERT INTO [zProgrammer_AntonioCollins].[dbo].[frm_RETL]([insertedBy], [dayofwk], [stdywk], [typedata], [weight], [participantGUID], [d_visit], [staffID], [bodyPart])
VALUES(1049, 2, 2, 1, 180, '6AD200F6-BF4F-4C83-8893-0A6CBDB9FB9F', '2018-08-08', '1049', 1);

INSERT INTO [zProgrammer_AntonioCollins].[dbo].[frm_RETL]([insertedBy], [dayofwk], [stdywk], [typedata], [weight], [participantGUID], [d_visit], [staffID], [bodyPart])
VALUES(1049, 3, 2, 1, 180, '6AD200F6-BF4F-4C83-8893-0A6CBDB9FB9F', '2018-08-08', '1049', 1);

INSERT INTO [zProgrammer_AntonioCollins].[dbo].[frm_RETL]([insertedBy], [dayofwk], [stdywk], [typedata], [weight], [participantGUID], [d_visit], [staffID], [bodyPart])
VALUES(1049, 3, 3, 1, 180, '6AD200F6-BF4F-4C83-8893-0A6CBDB9FB9F', '2018-08-08', '1049', 1);










